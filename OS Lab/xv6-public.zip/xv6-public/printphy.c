#include "types.h"
#include "user.h"
#include "stat.h"


int main(int argc,char* argv[]) { 
    
     printphy();
    exit();
}