#include "types.h"
#include "user.h"

int main(){
 print_schedule_info();
 exit();
}
